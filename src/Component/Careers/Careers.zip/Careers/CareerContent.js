import React from 'react'
import career from '../../images/career.webp'

const CareerContent = () => {
  return (
    <>
     <div className="container-fluid">
      <div className="container my-5">
        <div className="row align-items-center">
          <div className="col-md-6 hero-text">
            <h2>Make a difference! Join <br></br> team Groavy!</h2>
            <p>We empower our team with process and technology and encourage them to think creatively and drive bold changes to clients' agencies and businesses. Nextwebi is a hub for believers, thinkers, creators, and doers. You are welcome to join an enthusiastic team of zealous individuals in the world of technology and innovation. Join our quest in keeping up with the latest technology, innovation, and sustained professional and market growth.</p>
            <a href="#" className="btn btn-primary btn-view-jobs">View Jobs</a>
          </div>
          <div className="col-md-6 text-center">
            <img src={career} alt="Team Image" className="w-100" />
          </div>
        </div>
      </div>
    </div>

    
    </>
  )
}

export default CareerContent
